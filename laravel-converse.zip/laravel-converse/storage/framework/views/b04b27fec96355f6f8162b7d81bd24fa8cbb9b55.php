<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        if($material->type == "exam")
        {
            $type = "Prova";
        }elseif($material->type == "list")
        {
            $type = "Lista";
        }elseif($material->type == "resume")
        {
            $type = "Resumo";
        }elseif($material->type == "answer")
        {
            $type = "Gabarito";
        }
        ?>
        <div class="col-lg-4">
            <div class="box-option">
                <div class="box-top">
                    <div class="box-header">
                        <span class="box-title"><?php echo e($type); ?> de <?php echo e($material->content); ?>

                            <span class="box-info"><br><?php echo e($material->professor); ?></span>
                        </span>
                        
                    </div>
                </div>
                <a href="<?php echo e(url('/material')); ?>/<?php echo e($material->id); ?>" class="box-signup">Ver mais</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>