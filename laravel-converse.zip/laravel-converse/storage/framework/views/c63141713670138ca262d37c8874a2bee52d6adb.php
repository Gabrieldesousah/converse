<?php $__env->startSection('content'); ?>

        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/chat.css')); ?>" />
        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>" />

<br><br><br>
        <div class="col-lg-3" style="margin: 2% auto;">
            <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="chat/<?php echo e($c->id); ?>">Chat <?php echo e($c->id); ?> criado por <?php echo e($c->user_id); ?></a>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>