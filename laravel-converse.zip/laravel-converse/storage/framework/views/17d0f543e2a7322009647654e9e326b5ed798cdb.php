<form action="<?php echo e(url('/contentsInMass')); ?>" method="POST">

    <?php echo e(csrf_field()); ?>

    
    <select multiple name="content[]">
        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($m->content); ?>" selected><?php echo e($m->content); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><br>
    <input type="submit" value="Enviar" >
</form> 