<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e($user->name); ?></div>
                <div class="panel-body">
                    <p>
                        <b>Nome:</b> <?php echo e($user->name); ?><br>
                        <b>Email:</b> <?php echo e($user->email); ?><br>

                    <?php if($user->course != ''): ?>
                        <b>Curso:</b> <?php echo e($user->course); ?><br>
                    <?php endif; ?>
                    <?php if($user->college != ''): ?>
                        <b>Instituição:</b> <?php echo e($user->college); ?><br>
                    <?php endif; ?>
                    <?php if($user->state != '' and $user->city != ''): ?>
                        <?php echo e($user->state); ?> - <?php echo e($user->city); ?><br>
                    <?php endif; ?>
                    
                    <b>Categoria:</b>
                    	<?php if($user->permissions == 1): ?>
                    		Moderador
                    	<?php else: ?>
                    		Usuário padrão
                    	<?php endif; ?>

                    <?php if( Auth::user()->permissions == 1): ?>
                        <hr>
                            <td class="col-lg-3 right">
                                <a class="btn btn-warning" href="<?php echo e(url('/editprofile')); ?>/<?php echo e($user->id); ?>">
                                Editar</a>
                            </td>
                        </p>
                        <a href="<?php echo e(url('/users')); ?>">Voltar a lista de usuários</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>