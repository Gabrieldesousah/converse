<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4">
            <div class="box-option">
                <div class="box-top">
                    <div class="box-header">
                    	<span class="box-title"><?php echo e($content->name); ?></span>
                    </div>
                </div>
                <a href="<?php echo e(url('/contents')); ?>/<?php echo e($content->name); ?>" class="box-signup">Ver mais</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <br>
        <div class="centered">
            <?php echo e($contents->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>