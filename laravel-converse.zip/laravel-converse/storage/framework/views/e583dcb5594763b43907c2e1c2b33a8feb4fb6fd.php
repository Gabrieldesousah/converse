<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Usuários
                </div>
                <div class="panel-body">
                    <div class="table-container">
                    <form action="<?php echo e(url('/users/search')); ?>" method="GET">
                        <input type="text" name="key" class="form-control" placeholder="Pesquisar usuários">
                    </form>
	                    <table class="table table-condensed table-hover table-striped table-bordered col-lg-12">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->course); ?></td>
                                <td><?php echo e($user->created_at); ?></td>
                                <td><a href="<?php echo e(url('/user')); ?>/<?php echo e($user->id); ?>">Visualizar</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <div class="centered">
                            <?php echo e($users->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>