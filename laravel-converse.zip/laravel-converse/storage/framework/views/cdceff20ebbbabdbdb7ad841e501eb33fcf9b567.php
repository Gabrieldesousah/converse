<?php $__env->startSection('content'); ?>
<?php
if($material->type == "exam")
{
    $type = "Prova";
}elseif($material->type == "list")
{
    $type = "Lista";
}elseif($material->type == "resume")
{
    $type = "Resumo";
}elseif($material->type == "answer")
{
    $type = "Gabarito";
}
?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e($type); ?> de <?php echo e($material->content); ?></div>
                <div class="panel-body">
                <embed src="<?php echo e(url($file_path)); ?>" width="100%" height="600px"></embed>
                    <!--iframe src="<?php echo e(url($file_path)); ?>" width="100%" height="600px"-->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>