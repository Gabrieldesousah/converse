<form action="<?php echo e(url('/professorsInMass')); ?>" method="POST">

    <?php echo e(csrf_field()); ?>

    
    <select multiple name="professors[]">
        <?php $__currentLoopData = $professors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($p->professor); ?>" selected><?php echo e($p->professor); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><br>
    <input type="submit" value="Enviar" >
</form> 