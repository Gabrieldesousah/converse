<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    	<div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Resultado da pesquisa de "<?php echo e($search); ?>"</div>
                <div class="panel-body">
			    	<div class="table-container">
			    		<table claass="table table-striped col-lg-12">
			    		<tbody>
			    		<?php if( $materials == null ): ?>
			    		:/ Infelizmente não encontramos nada sobre "<?php echo e($search); ?>".
			    		<br>
			    		Tente utilizar outros termos ou então <a href="<?php echo e(url('/materials/share')); ?>">compartilhe o que você tem</a>

			    		<?php endif; ?>
					        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        <?php
					        if($material->type == "exam")
					        {
					            $type = "Prova";
					        }elseif($material->type == "list")
					        {
					            $type = "Lista";
					        }elseif($material->type == "resume")
					        {
					            $type = "Resumo";
					        }elseif($material->type == "answer")
					        {
					            $type = "Gabarito";
					        }
					        ?>
					        <tr>
					        	<td><?php echo e($type); ?> de <?php echo e($material->content); ?></td>
					            <td><?php echo e($material->professor); ?></td>
					            <td><?php echo e($material->description); ?></td>
					            <td><?php echo e($material->college); ?></td>
					            <td><a href="<?php echo e(url('/material')); ?>/<?php echo e($material->id); ?>" class="box-signup">Ver mais</a></td>
					        </tr>
					        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					    </tbody>
			        	</table>
        			</div>
    		    </div>
	        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>