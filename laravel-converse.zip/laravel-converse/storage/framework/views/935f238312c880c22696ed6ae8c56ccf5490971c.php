<nav class="navbar navbar-inverse navbar-fixed-top">
  <!--div>
    <div style="width:100%; background: #FFF; position: absolute; top:0;">
      Essa é uma versão de teste e pode estar instável nos primeiros dias.
    </div>
    <br>
  </div-->

    <div class="container">
        <div class="navbar-header">
            <!-- Collapsed Hamburger -->
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <!-- Branding Image -->
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php echo e(config('app.name', 'Seu Mérito')); ?>

            </a>
        </div>

        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <!-- Left Side Of Navbar -->
            <ul class="nav navbar-nav">
                &nbsp;
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="nav navbar-nav navbar-right">
                <!-- Authentication Links -->
                <li>
                    <form action="<?php echo e(url('/search/key')); ?>" method="GET">
                        <input type="text" name="key" class="form-control" placeholder="Pesquisar material">
                    </form>
                </li>
                <li><a href="<?php echo e(url('/materials/share')); ?>">Compartilhar</a></li>
                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(url('/login')); ?>?url=<?php echo e($_SERVER['REQUEST_URI']); ?>">Login</a></li>
                    <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" style="text-transform: capitalize;">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
                            </li>
                            
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
                                    Logout
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>