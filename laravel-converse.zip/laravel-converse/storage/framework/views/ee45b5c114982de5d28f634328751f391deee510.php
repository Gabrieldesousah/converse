<?php $__env->startSection('content'); ?>
<?php
if($material->type == "exam")
{
    $type = "Prova";
}elseif($material->type == "list")
{
    $type = "Lista";
}elseif($material->type == "resume")
{
    $type = "Resumo";
}elseif($material->type == "answer")
{
    $type = "Gabarito";
}
?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e($type); ?> de <?php echo e($material->content); ?></div>
                <div class="panel-body">
                    <p>

                    <?php if($material->professor != ''): ?>
                        <b>Professor(a):</b> <?php echo e($material->professor); ?><br>
                    <?php endif; ?>
                    <?php if($material->college != ''): ?>
                        <b>Instituição:</b> <?php echo e($material->college); ?><br>
                    <?php endif; ?>
                    <?php if($material->description != ''): ?>
                        <b>Descrição:</b> <?php echo e($material->description); ?><br>
                    <?php endif; ?>
                    <hr>
                    <?php if(Auth::guest()): ?>
                        <a href="<?php echo e(url('/login')); ?>?url=<?php echo e($_SERVER['REQUEST_URI']); ?>">Visualizar</a>
                    <?php else: ?>
                        <a target="_blank" href="<?php echo e(url('/file')); ?>/<?php echo e($material->id); ?>/<?php echo e($material->file); ?>">Visualizar</a>
                    <?php endif; ?>

                    <?php if( Auth::guest() ): ?>
                    <?php else: ?>
                    <?php #$user->id == $material->user_id ?>
                        <?php if( $user->permissions == 1): ?>
                        <td class="col-lg-3 right">
                            <a class="btn btn-warning" href="<?php echo e(url('/material/edit')); ?>/<?php echo e($material->id); ?>">
                            Editar</a>
                            <a class="btn btn-danger" href="<?php echo e(url('/material/destroy')); ?>/<?php echo e($material->id); ?>">
                            Apagar</a>
                        </td>
                        <?php endif; ?>
                      <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Comentários</div>
                <div class="panel-body">

                    <?php if(session('status_comment')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session('status_comment')); ?>

                        </div>
                    <?php endif; ?>

                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12 table-container">
                        <table class="table table-stripped">
                            <tr>
                                <td class="col-lg-9"><?php echo $c->body; ?></td>

                              <?php if( Auth::guest() ): ?>

                              <?php else: ?>
                                <?php if( $user->id === $c->user_id || $user->permissions == 1): ?>
                                <td class="col-lg-3 right">
                                    <a class="btn btn-warning" href="<?php echo e(url('/comments/edit')); ?>/<?php echo e($c->id); ?>">
                                    Editar</a>
                                    <a class="btn btn-danger" href="<?php echo e(url('/comments/destroy')); ?>/<?php echo e($c->id); ?>">
                                    Apagar</a>
                                </td>
                                <?php endif; ?>
                              <?php endif; ?>
                            </tr>
                        </table>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                    <div class="col-lg-12">
                      <?php if( !Auth::guest() ): ?>
                        <form action="<?php echo e(url('/comments/store')); ?>" method="post" enctype="multipart/form-data">
                            <label for="body">Comentar: </label><br>
                            <textarea name="body" id="body" class="input-large form-control"></textarea>
                            
                            <input type="hidden" name="material_id" value="<?php echo e($material->id); ?>">

                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">

                            <br>
                            <?php echo e(csrf_field()); ?>

                            <div class="centered">
                                <input class="btn btn-default" type="submit" value="Enviar">
                            </div>
                        </form>
                      <?php else: ?>
 
                        <div class="centered">
                            <a class="btn btn-default" href="<?php echo e(url('/login/materials/show/')); ?>/<?php echo e($material->id); ?>">Faça login para comentar</a>
                        </div>

                      <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>