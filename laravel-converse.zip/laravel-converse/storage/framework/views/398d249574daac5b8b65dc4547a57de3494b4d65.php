<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                  <ul>
                    <li style="text-transform: capitalize;"><?php echo e(Auth::user()->name); ?></li>
                    <li><?php echo e(Auth::user()->email); ?></li>
                    <li><?php echo e(Auth::user()->college); ?> - <?php echo e(Auth::user()->state); ?></li>
                    <li><?php echo e(Auth::user()->course); ?></li>
                  </ul>
                  <a href="<?php echo e(url('editprofile')); ?>">Editar dados</a> 
                  |
                  <a href="<?php echo e(url('editpass')); ?>">Editar senha</a> 

                  <?php if( Auth::user()->permissions == 1): ?>
                  <hr>
                      <a href="<?php echo e(url('/searches')); ?>">
                      Mais pesquisados</a>
                      |
                      <a href="<?php echo e(url('/actions')); ?>">
                      Usuários mais ativos</a>
                      |
                      <a href="<?php echo e(url('/users')); ?>">
                      Lista de usuários</a>
                  <?php endif; ?>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">Histórico</div>

                <div class="panel-body">
                  <ul>
                    <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($a->material->type) and $a->material->type != ""){ ?>
                    
                    <?php
                        if($a->material->type == "exam")
                        {
                            $type = "Prova";
                        }elseif($a->material->type == "list")
                        {
                            $type = "Lista";
                        }elseif($a->material->type == "resume")
                        {
                            $type = "Resumo";
                        }elseif($a->material->type == "answer")
                        {
                            $type = "Gabarito";
                        }
                    ?>
                      <li>
                        <a href="<?php echo e(url('/material')); ?>/<?php echo e($a->material_id); ?>"><?php echo e($type); ?> de <?php echo e($a->material->content); ?></a>
                      </li>
                      
                    <?php } ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">Compartilhados por você</div>

                <div class="panel-body">
                  <ul>
                    <?php $__currentLoopData = $shared; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    if($s->type == "exam")
                    {
                        $type = "Prova";
                    }elseif($s->type == "list")
                    {
                        $type = "Lista";
                    }elseif($s->type == "resume")
                    {
                        $type = "Resumo";
                    }elseif($s->type == "answer")
                    {
                        $type = "Gabarito";
                    }
                    ?>
                      <li>
                        <a href="<?php echo e(url('/material')); ?>/<?php echo e($s->id); ?>"><?php echo e($type); ?> de <?php echo e($s->content); ?></a>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">Comentários feitos por você</div>

                <div class="panel-body">
                  <ul>
                    <?php $__currentLoopData = $commented; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li>
                        <a href="<?php echo e(url('/material')); ?>/<?php echo e($c->material_id); ?>"><?php echo $c->body; ?></a>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul> 
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>