<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Pesquisas</div>
                <div class="panel-body">

                    <?php $__currentLoopData = $keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <ul>
                    	<li>
                    		<b style="text-transform: capitalize;">
                    			<?php echo e($keyword->keywords); ?>:
                    		</b>
                    		<?php echo e($keyword->count); ?>

                    	</li>
                    </ul>
            		
            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="centered">
                        <?php echo e($keywords->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>