<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <table>
            <tr>
                <td>user</td>
                <td>message</td>
                <td>created at</td>
            </tr>
            
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($message->user_id); ?></td>
                <td><?php echo e($message->message); ?></td>
                <td><?php echo e($message->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>