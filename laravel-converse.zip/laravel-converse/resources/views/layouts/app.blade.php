@include('layouts.header')

@include('layouts.navbar')

<br>
    
    @yield('content')
        


@include('layouts.footer')